﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using NJDGDetail.Models;

namespace NJDGDetail.Controllers
{
    public class DashboardController : Controller
    {
        //
        // GET: /Dashboard/

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult CaseDetailDashbord()
        {
            return View();
        }

        [HttpPost]
        public JsonResult GetMasterCaseData(string crtid = "",string username="")
        {
            try
            {

                CaseDetailObjectList courseEnrolList = CaseDetailObjeController.GetMasterCaseData(crtid,username);
                var clist = (from ob in courseEnrolList select new { casetype = ob.Court, casetypename = ob.Courtname}).Distinct().OrderBy(x => x.casetypename).ToList();
                return Json(clist, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { Result = "ERROR IN UPDATING STATUS", Message = "ERROR" }, JsonRequestBehavior.AllowGet);
            }
        }

    }
}
