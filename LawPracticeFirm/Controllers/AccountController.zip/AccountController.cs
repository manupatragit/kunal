﻿using System.Web.Mvc;
using LawPracticeFirm.Common;

namespace LawPracticeFirm.Controllers
{
    public class AccountController : BaseFirmController
    {
        public ActionResult Login(string RedirectUrl)
        {
            ViewBag.Url = string.Empty;
            if (!string.IsNullOrEmpty(RedirectUrl))
            {
                ViewBag.Url = RedirectUrl.Remove(0, 1);
            }
            
            return View();
        }

        public ActionResult Register()
        {
            return View();
        }

        public ActionResult ForgotPassword()
        {
            return View();
        }

        [FirmControllerAuthorization()]
        public ActionResult UserProfile()
        {
            return View();
        }

        [FirmControllerAuthorization()]
        public ActionResult ChangePassword()
        {
            return View();
        }

        [FirmControllerAuthorization()]
        public ActionResult LogOut()
        {
            RemoveSession(System.Web.HttpContext.Current);
            return View();
        }
    }
}