﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BussinessLogic.Common;
using DataAccess.Modals;
using LawPracticeFirm.Common;
using NJDGDetail.Models;
using BussinessLogic.BusinessEntity;
using Newtonsoft.Json.Linq;
using System.Web.Script.Serialization;

namespace LawPracticeFirm.Controllers
{
    public class EmployeeController : BaseFirmController
    {
        public EmployeeController()
        {
            
        }
        // GET: Company/Employee
        [FirmControllerAuthorization()]
        public ActionResult Index()
        {
            var json = new JavaScriptSerializer().Serialize(LoggedInUser);
            return View();
        }

        public ActionResult Settings()
        {
            return View();
        }       


        [FirmControllerAuthorization(Module = Module.Team,  AccessRight =AccessRight.ManageTeamUser)]
        public ActionResult TeamUsers(string caseid)
        {
            return View();
        }


        [FirmControllerAuthorization()]
        public ActionResult dashboard()
        {
            var db = new LawPracticeEntities();
            var loggeduser = LoggedInUser.UserId;
            var logd = LoggedInUser.FirmId;
            var username = db.FirmUsers.Where(x => x.Id == loggeduser).FirstOrDefault();
            Session["loggeduser"] = username.UserName;
            Session["usertype"] = username.IsFirmClient;
            var firmname = db.Firms.Where(z => z.Id == username.FirmId).FirstOrDefault();
            Session["firmname"] = firmname.FirmTitle;

            var totclient = db.RegClients.Where(d => d.firmId == username.FirmId).Count();
            ViewBag.countclient = totclient;
            var pendtask = db.AddTaskLists.Where(c => c.tstatus == "Pending" && c.firmid == username.FirmId).Count();
            ViewBag.pendtask = pendtask;

            var pendcase = db.AddLawMatterLists.Where(c => c.cstatus == "Pending" && c.firmId == username.FirmId).Count();
            ViewBag.pendcase = pendcase;

            var totmessage = db.MessageLists.Where(c => c.firmid == username.FirmId).Count();
            ViewBag.totmessage = totmessage;
            return View();
            return View();
        }


        [FirmControllerAuthorization]
        public ActionResult ProfileUpdate()
        {
            return View();
        }
        [FirmControllerAuthorization]
        public ActionResult UserProfile()
        {
            return View();
        }


        private LawPracticeEntities db = new LawPracticeEntities();

        [FirmControllerAuthorization]
        public ActionResult ConfigContact(string type)
        {
            var tfind = db.ConfigurationTypes.Where(x => x.Type == type).FirstOrDefault();
            if (tfind != null)
            {
                var types = tfind.Id;
                ViewBag.type = types;
                return View();
            }
            else
            {
                return View();
            }

        }

        // View contact
        [FirmControllerAuthorization]
        public ActionResult vcontact(string type)
        {

            var tfind = db.ConfigurationTypes.Where(x => x.Type == type).FirstOrDefault();
            if (tfind != null)
            {
                var types = tfind.Id;
                ViewBag.type = types;
                return View();
            }

            return View();
        }


        // Contact Single View 
        [FirmControllerAuthorization]
        public ActionResult ContactSingleView(string id)
        {
            var path = Request.Url.AbsolutePath;
            var cid = path.Split('/').Last();
        
            ViewBag.aid = cid;
            return View(id);
        }


        //addmatter

        [FirmControllerAuthorization]
        public ActionResult ConfigMatter(string type)
        {
            LawPracticeEntities db = new LawPracticeEntities();
            AddCaseObjectList addcase = new AddCaseObjectList();
            ViewBag.companydd1 =
            new SelectList(AddCaseObjectController.GetAllCourtname(), "Courtid", "Courtname", "select");


            var tfind = db.ConfigurationTypes.Where(x => x.Type == type).FirstOrDefault();
            if (tfind != null)
            {

                var types = tfind.Id;
                ViewBag.type = types;
                return View();
            }
            else
            {
                return View();
            }


            //return View();
        }


        // View matter
        [FirmControllerAuthorization]
        public ActionResult vmatter(string type)
        {
            var tfind = db.ConfigurationTypes.Where(x => x.Type == type).FirstOrDefault();
            if (tfind != null)
            {
                var types = tfind.Id;
                ViewBag.type = types;
                return View();
            }

            return View();
        }
        // Contact Single Edit 
        [FirmControllerAuthorization]
        public ActionResult ContactSingleEdit(string id)
        {
            var path = Request.Url.AbsolutePath;
            var cid = path.Split('/').Last();
            //var cidd = Convert.ToInt32(cid);
            //var db = new LawPracticeEntities();
            //var data = db.FirmUsers.Where(x => x.Id == cidd).Select(x=>new { x.fname,x.lname,x.mname }).FirstOrDefault();

            //var fullname = data.UserName;
            ViewBag.aid = cid;
            return View(id);

        }



        // Matter Single VIew 
        [FirmControllerAuthorization]
        public ActionResult MatterSingleView(string id)
        {
            ViewBag.aid = id;
            return View(id);

        }

        // Matter Single Edit 
        [FirmControllerAuthorization]
        public ActionResult MatterSingleEdit(string id)
        {
            ViewBag.aid = id;

            LawPracticeEntities db = new LawPracticeEntities();
            AddCaseObjectList addcase = new AddCaseObjectList();
            ViewBag.companydd1 =
            new SelectList(AddCaseObjectController.GetAllCourtname(), "Courtid", "Courtname", "select");


            var tfind = db.ConfigurationTypes.Where(x => x.Type == "matter").FirstOrDefault();
            if (tfind != null)
            {

                var types = tfind.Id;
                ViewBag.type = types;
                return View(id);
            }
            else
            {
                return View(id);
            }



        }

        [FirmControllerAuthorization]
        public ActionResult CaseDetails()
        {

            return View();
        }


    }
}