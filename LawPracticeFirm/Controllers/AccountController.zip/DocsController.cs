﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using LawPracticeFirm.Helpers;
using LawPracticeFirm.Models;
using System.Web.Http;
using BussinessLogic.BusinessEntity;
using BussinessLogic.Common;

using Newtonsoft.Json.Linq;
using DataAccess.Modals;
using CustomField = BussinessLogic.BusinessEntity.CustomField;
using DataAccess.PocoRepositories;
using System.Data.Entity;
using LawPracticeFirm.Common;
namespace LawPracticeFirm.Controllers
{
    public class DocsController : BaseFirmController
    {
        // GET: Docs
        public ActionResult Index()
        {
            return View();
        }
        [FirmControllerAuthorization]
        public ActionResult Editor(string fileName, string mode,string dname)
        {
            ViewBag.dname = dname;
            ViewBag.Firmid = LoggedInUser.FirmId.ToString();
            ViewBag.userid = LoggedInUser.UserId.ToString();
            mode = mode ?? string.Empty;

            var file = new FileModel
            {
                TypeDesktop = mode != "embedded",
                FileName = fileName
            };
           
            return View("Editor", file);
        }
        [FirmControllerAuthorization]
        public ActionResult Sample(string fileExt,string fname=null, string dname = null)
        {
         
            long d = LoggedInUser.FirmId;
            var fileName = DocManagerHelper.CreateDemo(fileExt,fname,dname, LoggedInUser.FirmId.ToString(),LoggedInUser.UserId.ToString());
            Response.Redirect(Url.Action("Editor", "Docs", new { fileName = fileName ,dname=dname}));
            return null;
        }

        [FirmControllerAuthorization]
        public ActionResult ViewSample (string fileName,string dname)
        {

            long d = LoggedInUser.FirmId;
            //var fileName = DocManagerHelper.CreateDemo(fileExt, fname, LoggedInUser.FirmId.ToString(), LoggedInUser.UserId.ToString());
            Response.Redirect(Url.Action("Editor", "Docs", new { fileName = fileName, dname = dname }));
            return null;
        }
        public ActionResult dat()
        {
            return View();
        }
    }
}