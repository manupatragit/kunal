﻿using System.Collections.Generic;
using System.Configuration;
using System.Web.Mvc;
using LawPracticeFirm.Common;
using System.Configuration;
using System.Data.SqlClient;
using System.Web.Script.Serialization;
using DataAccess.Modals;
using System.Web;
using System.IO;

namespace LawPracticeFirm.Controllers
{
    public class HomeController : BaseFirmController
    {
        // GET: Company/Home
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your Company description page.";

            return View();
        }

        [HttpPost]
        public ActionResult About(HttpPostedFileBase file)
        {

            if (file.ContentLength > 0)
            {
                var fileName = Path.GetFileName(file.FileName);
                var path = Path.Combine(Server.MapPath("~/documents/"), fileName);
                file.SaveAs(path);
            }

            return RedirectToAction("Index");
        }
        public ActionResult Contact()
        {
            ViewBag.Message = "Your Company contact page.";
           
            return View();
        }


        public ActionResult Articles()
        {
            ViewBag.Message = "Your Company contact page.";

            return View();
        }

        public ActionResult Article()
        {
            ViewBag.Message = "Your Company contact page.";

            return View();
        }

        public ActionResult Won()
        {
            ViewBag.Message = "Your Company contact page.";

            return View();
        }

        public ActionResult Practice()
        {
            ViewBag.Message = "Your Company contact page.";

            return View();
        }
        public ActionResult AddPractice()
        {
            ViewBag.Message = "Your Company contact page.";

            return View();
        }

        public ActionResult CField()
        {
            ViewBag.Message = "Your Company contact page.";

            return View();
        }
        [HttpPost]
        public ActionResult CField(string DynamicTextBox, string DynamicTextDate,string cities, AddContactsList ct)
        {
            LawPracticeEntities dc = new LawPracticeEntities();
            //Serialize the Array and assign to ViewBag.
           //JavaScriptSerializer serializer = new JavaScriptSerializer();
          //ViewBag.Values = serializer.Serialize(DynamicTextBox);
        // var cy = serializer.Serialize(DynamicTextDate);
            //Loop through the dynamic TextBox values.
            
                AddContactsList cd = new AddContactsList();
                cd.lname = DynamicTextBox;
                cd.fname = ct.fname;
                cd.homeno = DynamicTextDate;
                //cd.city = cities;
                dc.AddContactsLists.Add(cd);
                dc.SaveChanges();

                //string constr = ConfigurationManager.ConnectionStrings["constr"].ConnectionString;
                //using (SqlConnection con = new SqlConnection(constr))
                //{
                //    using (SqlCommand cmd = new SqlCommand("INSERT INTO Names(Name) VALUES(@Name)"))
                //    {
                //        cmd.Connection = con;
                //        cmd.Parameters.AddWithValue("@Name", textboxValue);
                //        con.Open();
                //        cmd.ExecuteNonQuery();
                //        con.Close();
                //    }
                //}
            

            //Set the Message to be displayed later in View.
            ViewBag.Message = DynamicTextBox + " records saved.";

            return View();
        }


    }
}