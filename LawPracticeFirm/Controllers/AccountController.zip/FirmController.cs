﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BussinessLogic.Common;
using DataAccess.Modals;
using LawPracticeFirm.Common;
using NJDGDetail.Models;
using BussinessLogic.BusinessEntity;
using Newtonsoft.Json.Linq;
namespace LawPracticeFirm.Controllers
{
    public class FirmController : BaseFirmController
    {
        [FirmControllerAuthorization(Module = Module.Firm)]
        public ActionResult FirmInformation()
        {
         
            return View();
        }

        [FirmControllerAuthorization]
        public ActionResult List(string type, int id = 0)
        {
           var module= Enum.Parse(typeof(ModuleType), type);
            ViewBag.ConfType = Convert.ToInt32(module);
            ViewBag.Header = Convert.ToString(module);
            ViewBag.Id = id;
            return View();
        }

        [FirmControllerAuthorization]
        public ActionResult Detail(string type,int id= 0)
        {
            var module = Enum.Parse(typeof(ModuleType), type);
            ViewBag.ConfType = Convert.ToInt32(module);
            ViewBag.Header = Convert.ToString(module);
            ViewBag.Id = id;
            return View();
        }

        [FirmControllerAuthorization]
        public ActionResult AddNew(string type)
        {
            ViewBag.Type = type;
            return View();
        }


       
        public ActionResult test()
        {
            
            return View();
        }
        [FirmControllerAuthorization]
        public ActionResult Add(string type)
        {
            var module = Enum.Parse(typeof(ModuleType), type);
            ViewBag.ConfType = Convert.ToInt32(module);
            ViewBag.Id = 0;
            ViewBag.Header = Convert.ToString(module);
            return PartialView();
        }

        [FirmControllerAuthorization]
        public ActionResult Configure(string type, int id = 0)
        {
            ViewBag.Type = type;
            ViewBag.Id = id;
            return View();
        }

        [FirmControllerAuthorization]
        public ActionResult Configuration(string type, int id = 0)
        {
            var module = Enum.Parse(typeof(ModuleType), type);
            ViewBag.ConfType = Convert.ToInt32(module);
            ViewBag.Id = id;
            ViewBag.Header = Convert.ToString(module);
            return PartialView();
        }

        [FirmControllerAuthorization]
        public ActionResult WorkFlow(int type = 0)
        {
            ViewBag.Id = type;
            return View();
        }

        [FirmControllerAuthorization]
        public ActionResult WorkFlowList(int type = 0)
        {
            ViewBag.Id = type;
            return View();
        }

        [FirmControllerAuthorization]
        public ActionResult WorkFlowAttach(int type = 0, int id = 0)
        {
            ViewBag.WorkFlowId = type;
            ViewBag.AttachId = id;
            return View();
        }




        [FirmControllerAuthorization]
        public ActionResult CustomFormList(string type)
        {
            var module = Enum.Parse(typeof(ModuleType), type);
            ViewBag.ConfType = Convert.ToInt32(module);
            ViewBag.Id = 0;
            ViewBag.Header = Convert.ToString(module);
            return View();
        }

        [FirmControllerAuthorization]
        public ActionResult AddCustomForm(string type)
        {
            var module = Enum.Parse(typeof(ModuleType), type);
            ViewBag.ConfType = Convert.ToInt32(module);
            ViewBag.Id = 0;
            ViewBag.Header = Convert.ToString(module);
            return PartialView();
        }

        [FirmControllerAuthorization]
        public ActionResult AddNewCustomForm(string type)
        {
            ViewBag.Type = type;
            return View();
        }

        [FirmControllerAuthorization]
        public ActionResult CustomFormDetail(string type, int id = 0)
        {
            var module = Enum.Parse(typeof(ModuleType), type);
            ViewBag.ConfType = Convert.ToInt32(module);
            ViewBag.Header = Convert.ToString(module);
            ViewBag.Id = id;
            return View();
        }


        private LawPracticeEntities db = new LawPracticeEntities();

        [FirmControllerAuthorization]
        public ActionResult ConfigContact(string type)
        {
            var tfind = db.ConfigurationTypes.Where(x => x.Type == type).FirstOrDefault();
            if (tfind != null)
            {
                var types = tfind.Id;
                 ViewBag.type = types;
                return View();        
            }
       else
        {
                return View();
        }
         
        }



        //addmatter

        [FirmControllerAuthorization]
        public ActionResult ConfigMatter(string type)
        {
            LawPracticeEntities db = new LawPracticeEntities();
            AddCaseObjectList addcase = new AddCaseObjectList();
            ViewBag.companydd1 =
            new SelectList(AddCaseObjectController.GetAllCourtname(), "Courtid", "Courtname", "select");


            var tfind = db.ConfigurationTypes.Where(x => x.Type == type).FirstOrDefault();
            if (tfind != null)
            {
                
                var types = tfind.Id;
                ViewBag.type = types;
                return View();
            }
            else
            {
                return View();
            }


            //return View();
        }



     

        // Add Dashboard

        [FirmControllerAuthorization]
        public ActionResult DashBoard()
        {

            var db = new LawPracticeEntities();
            var loggeduser = LoggedInUser.UserId;
            var logd = LoggedInUser.FirmId;
            var username = db.FirmUsers.Where(x => x.Id == loggeduser).FirstOrDefault();
            Session["loggeduser"] = username.UserName;
            Session["usertype"] = username.IsFirmClient;
            var firmname = db.Firms.Where(z => z.Id == username.FirmId).FirstOrDefault();
            Session["firmname"] = firmname.FirmTitle;

            var totclient = db.RegClients.Where(d=>d.firmId==username.FirmId).Count();
            ViewBag.countclient = totclient;
            var pendtask = db.AddTaskLists.Where(c=>c.tstatus=="Pending" && c.firmid==username.FirmId).Count();
            ViewBag.pendtask = pendtask;

            var pendcase = db.AddLawMatterLists.Where(c => c.cstatus == "Pending" && c.firmId == username.FirmId).Count();
            ViewBag.pendcase = pendcase;

            var totmessage = db.MessageLists.Where(c=>c.firmid == username.FirmId).Count();
            ViewBag.totmessage = totmessage;
            return View();
      
        }

        // Calender

        [FirmControllerAuthorization]
        public ActionResult Calender()
        {
            return View();

        }
        // Matter cAleedar

        [FirmControllerAuthorization]
        public ActionResult MatterCalender()
        {
            return View();

        }

        [FirmControllerAuthorization]
        public ActionResult Activities()
        {
            return View();

        }


        // Add event
        [FirmControllerAuthorization]
        public ActionResult ConfigEvent()
        {
            return View();

        }

        // Edit event
        [FirmControllerAuthorization]
        public ActionResult ConfigEventEdit(string ids)
        {
            return View();

        }

        // Add Call
        [FirmControllerAuthorization]
        public ActionResult ConfigCall()
        {
            return View();

        }
        // Edit Call
        [FirmControllerAuthorization]
        public ActionResult ConfigCallEdit(string ids)
        {
            return View();

        }

        // Add Note
        [FirmControllerAuthorization]
        public ActionResult ConfigNote()
        {
            return View();

        }

        // Edit Note
        [FirmControllerAuthorization]
        public ActionResult ConfigNoteEdit(string ids)
        {
            return View();

        }
        // Add Task
        [FirmControllerAuthorization]
        public ActionResult ConfigTask()
        {
            return View();

        }
        // Edit Task
        [FirmControllerAuthorization]
        public ActionResult ConfigTaskEdit(string ids)
        {
            return View();

        }


        // Add Call
        [FirmControllerAuthorization]
        public ActionResult ConfigTimer()
        {
            return View();

        }

        // View Timer
        [FirmControllerAuthorization]
        public ActionResult ViewTimer()
        {
            return View();

        }
        // Matter Single VIew 
        [FirmControllerAuthorization]
        public ActionResult MatterSingleView(string id)
        {
            ViewBag.aid = id;
            return View(id);

        }

        // Matter Single Edit 
        [FirmControllerAuthorization]
        public ActionResult MatterSingleEdit(string id)
        {
            ViewBag.aid = id;

            LawPracticeEntities db = new LawPracticeEntities();
            AddCaseObjectList addcase = new AddCaseObjectList();
            ViewBag.companydd1 =
            new SelectList(AddCaseObjectController.GetAllCourtname(), "Courtid", "Courtname", "select");


            var tfind = db.ConfigurationTypes.Where(x => x.Type == "matter").FirstOrDefault();
            if (tfind != null)
            {

                var types = tfind.Id;
                ViewBag.type = types;
                return View(id);
            }
            else
            {
                return View(id);
            }

           

        }

        // Contact Single View 
        [FirmControllerAuthorization]
        public ActionResult ContactSingleView(string id)
        {
            ViewBag.aid = id;
            return View(id);

        }

        // Contact Single Edit 
        [FirmControllerAuthorization]
        public ActionResult ContactSingleEdit(string id)
        {
            var path = Request.Url.AbsolutePath;
          var cid= path.Split('/').Last();
            //var cidd = Convert.ToInt32(cid);
            //var db = new LawPracticeEntities();
            //var data = db.FirmUsers.Where(x => x.Id == cidd).Select(x=>new { x.fname,x.lname,x.mname }).FirstOrDefault();

            //var fullname = data.UserName;
            //ViewBag.aid = fullname;
            return View(id);

        }

        // Custom Form Data Update
        [FirmControllerAuthorization]
        public ActionResult CustomFormDataUpdate(string id)
        {
           // ViewBag.aid = id;
            return View(id);

        }

        

        // View Single Task 
        [FirmControllerAuthorization]
        public ActionResult TaskSingleView(string id = null)
        {
            ViewBag.aid = id;
            return View(id);

        }
        // View Single Event 
        [FirmControllerAuthorization]
        public ActionResult EventSingleView(string ids)
        {
            ViewBag.aid = ids;
            return View();

        }

        //  template  
        [FirmControllerAuthorization]
        public ActionResult CreateTemplate()
        {
         
            return View();

        }

        //  view template  
        [FirmControllerAuthorization]
        public ActionResult ViewTemplate()
        {
        
            return View();

        }
        // Create Files Directory and files
        [FirmControllerAuthorization]
        public ActionResult AttachFiles()
        {
            
            return View();

        }

        // View FilesList
        [FirmControllerAuthorization]
        public ActionResult FilesList()
        {
            ViewBag.userId = LoggedInUser.UserId;

            ViewBag.firmid = LoggedInUser.FirmId;
            return View();

        }

        // View FilesList
        [FirmControllerAuthorization]
        public ActionResult UserFilesList()
        {

            return View();

        }
        // View Single Note 
        [FirmControllerAuthorization]
        public ActionResult NoteSingleView(string ids)
        {
            ViewBag.aid = ids;
            return View();

        }
        // View Single Call 
        [FirmControllerAuthorization]
        public ActionResult CallSingleView(string ids )
        {
            ViewBag.aid = ids;
            return View();

        }


        // Live Preview Custom Form 
        [FirmControllerAuthorization]
        public ActionResult LivePagePreview(string id)
        {

            return View();

        }



        // Edit Custom Form 
        [FirmControllerAuthorization]
        public ActionResult EditCustomForm(string id)
        {

            return View();

        }

        // Create Custom Form 
        [FirmControllerAuthorization]
        public ActionResult CreateCustomForm()
        {
            
            return View();

        }

        // View Custom Form 
        [FirmControllerAuthorization]
        public ActionResult ViewCustomForm()
        {

            return View();

        }

        // View Custom Form List
        [FirmControllerAuthorization]
        public ActionResult Customform()
        {

            return View();

        }

        // verify Custom Form List
        [FirmControllerAuthorization]
        public ActionResult Customformverify()
        {

            return View();

        }

        // download Custom Form List
        [FirmControllerAuthorization]
        public ActionResult Customformdownload()
        {

            return View();

        }
        public ActionResult contact()
        {
            return View();
        }

        // View contact
        [FirmControllerAuthorization]
        public ActionResult vcontact(string type)
        {

            var tfind = db.ConfigurationTypes.Where(x => x.Type == type).FirstOrDefault();
            if (tfind != null)
            {
                var types = tfind.Id;
                 ViewBag.type = types;
                    return View();
            }
        
            return View();
        }

        // View matter
        [FirmControllerAuthorization]
        public ActionResult vmatter(string type)
        { 
            var tfind = db.ConfigurationTypes.Where(x => x.Type == type).FirstOrDefault();
            if (tfind != null)
            {
                var types = tfind.Id;
                ViewBag.type = types;
                return View();
            }
           
            return View();
        }



        // Add Lead
        [FirmControllerAuthorization]
        public ActionResult CreateLead()
        {
            return View();

        }

        // view Lead
        [FirmControllerAuthorization]
        public ActionResult ViewLead()
        {
            return View();

        }
        // view Lead
        [FirmControllerAuthorization]
        public ActionResult LeadSingleView()
        {
            return View();

        }

        // view Lead
        [FirmControllerAuthorization]
        public ActionResult LeadSingleEdit()
        {
            return View();

        }
        [FirmControllerAuthorization]

        public ActionResult WorkFlowNew()
        {
            return View();
        }
        [FirmControllerAuthorization]

        public ActionResult WorkFlowNewType()
        {
            return View();
        }
        [FirmControllerAuthorization]

        public ActionResult WorkFlowNewForm()
        {
            return View();
        }
        [FirmControllerAuthorization]

        public ActionResult WorkFlowNewTask()
        {
            return View();
        }
        [FirmControllerAuthorization]

        public ActionResult WorkFlowNewStage1()
        {
            return View();
        }
        [FirmControllerAuthorization]

        public ActionResult WorkFlowNewStage2()
        {
            return View();
        }
        [FirmControllerAuthorization]

        public ActionResult WorkFlowNewStage3()
        {
            return View();
        }
        [FirmControllerAuthorization]

        public ActionResult WorkFlowNewStage4()
        {
            return View();
        }
        [FirmControllerAuthorization]
        public ActionResult WorkFlowN()
        {
            return View();
        }
        [FirmControllerAuthorization]

        public ActionResult WorkFlowNApply()
        {
            return View();
        }
        [FirmControllerAuthorization]

        public ActionResult SearchFirm()
        {
            return View();
        }
        [FirmControllerAuthorization]

        public ActionResult WorkFlowNList()
        {
            return View();
        }
        [FirmControllerAuthorization]

        public ActionResult WorkFlowNApplyRequest()
        {
            return View();
        }
        public ActionResult UserActivity()
        {
            return View();
        }
        [FirmControllerAuthorization]

        public ActionResult WorkFlowNUserActivity()
        {
            return View();
        }
        [FirmControllerAuthorization]

        public ActionResult WorkFlowNStatus()
        {
            return View();
        }
        [FirmControllerAuthorization]

        public ActionResult TaskList()
        {
            return View();
        }
        [FirmControllerAuthorization]

        public ActionResult TaskStatusUpdate()
        {
            return View();
        }

        [FirmControllerAuthorization]

        public ActionResult CustomFormSendmail()
        {
            return View();
        }

        [FirmControllerAuthorization]
        public ActionResult WorkflowReport()
        {
            return View();
        }

        [FirmControllerAuthorization]
        public ActionResult WorkflowFileList()
        {
          
            return View();
        }

        [FirmControllerAuthorization]
        public ActionResult ConfigMessage()
        {

            return View();
        }

        [FirmControllerAuthorization]
        public ActionResult ConfigMessageList()
        {

            return View();
        }
        [FirmControllerAuthorization]
        public ActionResult ConfigMessageSingleView()
        {

            return View();
        }

        [FirmControllerAuthorization]
        public ActionResult ConfigMessageSingleEdit()
        {

            return View();
        }

        [FirmControllerAuthorization]
        public ActionResult CreateClient()
        {

            return View();
        }

        [FirmControllerAuthorization]
        public ActionResult ClientList()
        {

            return View();
        }

        [FirmControllerAuthorization]
        public ActionResult EditClient()
        {

            return View();
        }



        [FirmControllerAuthorization]
        public ActionResult CreateUser()
        {

            return View();
        }

        [FirmControllerAuthorization]
        public ActionResult UserList()
        {

            return View();
        }

        [FirmControllerAuthorization]
        public ActionResult EditUser()
        {

            return View();
        }


        [HttpPost]
        [FirmControllerAuthorization]
        public JsonResult Leaduser(string Prefix)
        {

            var leaduser = (from c in db.LeadLists
                             where  c.ldname.StartsWith(Prefix)&& c.firmid==LoggedInUser.FirmId
                             select new { label=c.ldname,
                                 val=c.lid }).ToList();
            return Json(leaduser, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        [FirmControllerAuthorization]
        public ActionResult LeadUserListlogin(long Prefix)
        {
            var db = new LawPracticeEntities();
            var user = LoggedInUser.FirmId;
            var getclientid = db.RegClients.Where(c => c.leadid == Prefix && c.firmId==LoggedInUser.FirmId).FirstOrDefault();
            if(getclientid!=null)
            {

            
            var leaduser = (from c in db.FirmUsers
                            where c.clientId==getclientid.Id && c.FirmId == LoggedInUser.FirmId
                            select new
                            {
                                username = c.UserName,
                                password = c.Password
                            }).ToList();
                return Json(leaduser, JsonRequestBehavior.AllowGet);
            }
            else
            {
                var data ="null";
                return Json(data, JsonRequestBehavior.AllowGet);
            }
            
        }

        public ActionResult testdata()
        {

            return View();
        }

       
        [FirmControllerAuthorization]
        public ActionResult CaseDetails()
        {

            return View();
        }
    }
}