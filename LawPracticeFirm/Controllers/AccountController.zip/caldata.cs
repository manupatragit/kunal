﻿using System.Collections.Generic;

namespace LawPracticeFirm.Controllers
{
    public class caldata
    {
        public int id { get; internal set; }      
        public string text { get; internal set; }
        public string start_date { get; internal set; }
        public string end_date { get; internal set; }
    }
    public class caldatalist:List<caldata>
    {
        public caldatalist()
        {

        }
    }

    public class User
    {
        public string name { get; internal set; }
       
    }
    public class Userlist:List<User>
    {
        public string name { get; internal set; }

    }
}