﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DataAccess.Modals;
using LawPracticeFirm.Common;
using NJDGDetail.Controllers;
using NJDGDetail.Models;

namespace LawPracticeFirm.Controllers
{
    public class ClientController : BaseFirmController
    {
        [FirmControllerAuthorization]
        public ActionResult Index()
        {
            return View();
        }
        [FirmControllerAuthorization]
        public ActionResult Dashboard()
        {
            var db = new LawPracticeEntities();
            var loggeduser = LoggedInUser.UserId;
            var logd = LoggedInUser.FirmId;
            var username = db.FirmUsers.Where(x => x.Id == loggeduser).FirstOrDefault();
            Session["loggeduser"] = username.UserName;
            Session["usertype"] = username.IsFirmClient;
            var firmname = db.Firms.Where(z => z.Id == username.FirmId).FirstOrDefault();
            Session["firmname"] = firmname.FirmTitle;

            var totclient = db.RegClients.Where(d => d.firmId == username.FirmId).Count();
            ViewBag.countclient = totclient;
            var pendtask = db.AddTaskLists.Where(c => c.tstatus == "Pending" && c.firmid == username.FirmId).Count();
            ViewBag.pendtask = pendtask;

            var pendcase = db.AddLawMatterLists.Where(c => c.cstatus == "Pending" && c.firmId == username.FirmId).Count();
            ViewBag.pendcase = pendcase;

            var totmessage = db.MessageLists.Where(c => c.firmid == username.FirmId).Count();
            ViewBag.totmessage = totmessage;
            return View();

        }
        [FirmControllerAuthorization]
        public ActionResult ProfileUpdate()
        {
            return View();
        }
        [FirmControllerAuthorization]
        public ActionResult Profile()
        {
            return View();
        }
        [FirmControllerAuthorization]
        public ActionResult Calender()
        {
            return View();
        }
        [FirmControllerAuthorization]
        public ActionResult MatterList()
        {
            return View();
        }
        [FirmControllerAuthorization]
        public ActionResult ChangePassword()
        {
            return View();
        }
        [FirmControllerAuthorization]
        public ActionResult Calendar()
        {
            return View();
        }
        [FirmControllerAuthorization]
        [HttpPost]
        public JsonResult CalendarViewDataDetail()
        {
            dynamic strdetail = "";
            EventList recentlyViewedEvent1;
            dynamic str = null;

             EventList recentlyViewedEvent = NJDGDetail.Controllers.CalendarEventController.CountCaseBYUserName(Convert.ToString(Request.Form["id"]));
           // EventList recentlyViewedEvent = NJDGDetail.Controllers.CalendarEventController.CountCaseBYUserName("1613");
            foreach (var myevent in recentlyViewedEvent)
            {
                recentlyViewedEvent1 = NJDGDetail.Controllers.CalendarEventController.GetCalendarEventByUserName1(Convert.ToString(myevent.username_), myevent.Disposeddt);
                str = recentlyViewedEvent1.ToList();
            }
            return Json(str, JsonRequestBehavior.AllowGet);
        }

        [FirmControllerAuthorization]
        [HttpPost]
        public JsonResult CalendarViewDataDetailFirm()
        {
            dynamic strdetail = "";
            EventList recentlyViewedEvent1;
            dynamic str = null;
            EventList recentlyViewedEvent = NJDGDetail.Controllers.CalendarEventController.CountCaseBYFirmUserId(Convert.ToString(Request.Form["id"]));
            //EventList recentlyViewedEvent = NJDGDetail.Controllers.CalendarEventController.CountCaseBYUserName("921");
            foreach (var myevent in recentlyViewedEvent)
            {
                recentlyViewedEvent1 = NJDGDetail.Controllers.CalendarEventController.GetCalendarEventByUserName1(Convert.ToString(myevent.username_), myevent.Disposeddt);
                str = recentlyViewedEvent1.ToList();
            }
            return Json(str, JsonRequestBehavior.AllowGet);
        }

        [FirmControllerAuthorization]

        public ActionResult WorkFlowNUserActivity()
        {
            return View();
        }

        [FirmControllerAuthorization]

        public ActionResult TaskList()
        {
            return View();
        }

        // Matter Single VIew 
        [FirmControllerAuthorization]
        public ActionResult MatterSingleView(string id)
        {
            ViewBag.aid = id;
            return View(id);

        }

        // View Custom Form List
        [FirmControllerAuthorization]
        public ActionResult Customform()
        {

            return View();

        }

        // download Custom Form List
        [FirmControllerAuthorization]
        public ActionResult Customformdownload()
        {

            return View();

        }

        // Live Preview Custom Form 
        [FirmControllerAuthorization]
        public ActionResult LivePagePreview(string id)
        {

            return View();

        }

        [FirmControllerAuthorization]

        public ActionResult CustomFormSendmail()
        {
            return View();
        }

        // Custom Form Data Update
        [FirmControllerAuthorization]
        public ActionResult CustomFormDataUpdate(string id)
        {
            // ViewBag.aid = id;
            return View(id);

        }

        [FirmControllerAuthorization]
        [HttpPost]
        public JsonResult CalendarViewDataDetailNxtHeardt()
        {
            dynamic strdetail = "";
            EventList recentlyViewedEvent3 = CalendarEventController.GetDistinctNextHearingByUser(Convert.ToString(LoggedInUser.UserId), "");

            dynamic str1="";
            foreach (var myevent3 in recentlyViewedEvent3)
            {

                EventList recentlyViewedEvent2 = CalendarEventController.GetNextHearingByUser(Convert.ToString(LoggedInUser.UserId), myevent3.Disposeddt);

                foreach (var myevent2 in recentlyViewedEvent2)
                {
                    if (recentlyViewedEvent2.Count > 0)
                    {
                        if (recentlyViewedEvent2.Count > 1)
                        {
                            // str1 = myevent2.Casetype + " " + myevent2.CaseNo + "/" + myevent2.Caseyear + " (" + myevent2.Disposeddt + ") " + "<a class=\"more\" href=\"#\" data-toggle=\"modal\" data-target=\"#modalDatebindBysuser\" name=\"register\" onclick=\"NexthearingbyUser('" + myevent2.Disposeddt + "');\">" + "More Next Hearing</a>";//" Next Hearing";
                            str1 = recentlyViewedEvent2.ToList();                                                                                                                                                                                                                                                                                                                     // myevent2.text = myevent2.Casetype + " " + myevent2.CaseNo + "/" + myevent2.Caseyear + " (" + myevent2.Disposeddt + ") " + "<a class=\"more\" href=\"#\" data-toggle=\"modal\" data-target=\"#modalDatebindBysuser\" name=\"register\" onclick=\"NexthearingbyUser('" + myevent2.Disposeddt + "');\">" + "More Next Hearing</a>";//" Next Hearing";
                                                                                                                                                                                                                                                                                                                                                   // myevent1.text = myevent2.text;
                        }
                        else
                        {
                            //str1 = "<a class=\"more\" href=\"#\" data-toggle=\"modal\" data-target=\"#modalDatebindBysuser\" name=\"register\" onclick=\"NexthearingbyUser('" + myevent2.Disposeddt + "');\">" + myevent2.Casetype + " " + myevent2.CaseNo + "/" + myevent2.Caseyear + " (" + myevent2.Disposeddt + ") " + "Next Hearing</a>";//" Next Hearing";
                            str1 = recentlyViewedEvent2.ToList();                                                                                                                                                                                                                                                                                                          //  myevent2.text = "<a class=\"more\" href=\"#\" data-toggle=\"modal\" data-target=\"#modalDatebindBysuser\" name=\"register\" onclick=\"NexthearingbyUser('" + myevent2.Disposeddt + "');\">" + myevent2.Casetype + " " + myevent2.CaseNo + "/" + myevent2.Caseyear + " (" + myevent2.Disposeddt + ") " + "Next Hearing</a>";//" Next Hearing";
                                                                                                                                                                                                                                                                                                                                                                           // myevent1.text = myevent2.text;
                        }
                    }
                }
            }
            return Json(str1, JsonRequestBehavior.AllowGet);
        }

    }
}