﻿using System;
using System.Linq;
using System.Web.Mvc;
using NJDGDetail.Models;

namespace NJDGDetail.Controllers
{
    public class AddCaseController : Controller
    {
        //
        // GET: /AddCase/

        public ActionResult AddCase()
        {
            return View();
        }

        [HttpPost]
        public JsonResult Addcasetype(string crtid = "",string courttitle="",string bench="",string side="")
        {
            try
            {

                AddCaseObjectList courseEnrolList = AddCaseObjectController.GetAllCaseTypeByCourtId(crtid,courttitle,bench,side); 
                var clist = (from ob in courseEnrolList select new { casetype = ob.Casetype, casetypename= ob.Casetypename}).Distinct().OrderBy(x => x.casetypename).ToList();
                return Json(clist, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { Result = "ERROR IN UPDATING STATUS", Message = "ERROR" }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        public JsonResult AddcasetypeITCE(string crtid = "", string courttitle = "", string bench = "", string side = "")
        {
            try
            {

                AddCaseObjectList courseEnrolList = AddCaseObjectController.GetAllCaseTypeByCourtId(crtid, courttitle, bench, side);
                var clist = (from ob in courseEnrolList select new { casetype = ob.Casetype, casetypename = ob.Casetypename }).Distinct().OrderBy(x => x.casetypename).ToList();
                return Json(clist, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { Result = "ERROR IN UPDATING STATUS", Message = "ERROR" }, JsonRequestBehavior.AllowGet);
            }
        }

        

        [HttpPost]
        public JsonResult GetBenchName(string crtid = "")
        {
            try
            {

                AddCaseObjectList courseEnrolList = AddCaseObjectController.GetBench(crtid);
                var clist = (from ob in courseEnrolList select new { casetype = ob.BenchID, casetypename = ob.Benchname }).Distinct().OrderBy(x => x.casetypename).ToList();
                return Json(clist, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { Result = "ERROR IN UPDATING STATUS", Message = "ERROR" }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        public JsonResult GetSide(string benchid = "")
        {
            try
            {
                AddCaseObjectList courseEnrolList = AddCaseObjectController.GetSide(benchid);
                var clist = (from ob in courseEnrolList select new { casetype = ob.SideID, casetypename = ob.Sidename }).Distinct().OrderBy(x => x.casetypename).ToList();
                return Json(clist, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { Result = "ERROR IN UPDATING STATUS", Message = "ERROR" }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        public JsonResult AddBenchtype(string bench = "")
        {
            try
            {
                AddCaseObjectList courseEnrolList = AddCaseObjectController.GetBenchType(bench);
                var clist = (from ob in courseEnrolList select new { casetype = ob.BenchID, casetypename = ob.Benchname}).Distinct().OrderBy(x => x.casetypename).ToList();
                return Json(clist, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { Result = "ERROR IN UPDATING STATUS", Message = "ERROR" }, JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult InsertCaseDetail()
        {
            int aff = 0;
            AddCaseObject addcase = new AddCaseObject();
            if (Request.Form["drpcourtname"].ToString() != "0")
            {
                addcase.Caseno = Request.Form["txtno"].ToString();
                addcase.Casetype = Request.Form["drptype"].ToString();
                addcase.Caseyear = Request.Form["drpYear"].ToString();
                addcase.Court = Request.Form["drpcourtname"].ToString();
               // addcase.Username = Convert.ToString(Session[Global.LOGGED_USERID]);
                addcase.FileNo = Request.Form["txtFileNo"].ToString();
                addcase.BenchID = "";
                addcase.SideID = "";
                addcase.Courttitle = "";
                addcase.Stampreg = "";


                if (Request.Form["drpcourtname"].ToString() == "KA")
                {
                    addcase.BenchID = Request.Form["drpKAbench"].ToString();
                }
                else if (Request.Form["drpcourtname"].ToString() == "MH")
                {
                    if (Request.Form["drpGoa"].ToString() == "")
                    {
                        addcase.BenchID = Request.Form["drpbench"].ToString();
                        addcase.SideID = Request.Form["drpside"].ToString();
                        addcase.Courttitle = Request.Form["drpGoa"].ToString();
                        addcase.Stampreg = Request.Form["drpstampregister"].ToString();
                    }
                    else
                    {
                        addcase.Courttitle = Request.Form["drpGoa"].ToString();
                    }
                }
                else if (Request.Form["drpcourtname"].ToString() == "NC" || Request.Form["drpcourtname"].ToString() == "NL")
                {
                    addcase.Casetype = "";
                    addcase.BenchID = Request.Form["drpNCBench"].ToString();
                }

                else if (Request.Form["drpcourtname"].ToString() == "IT" || Request.Form["drpcourtname"].ToString() == "CE")
                {
                    addcase.BenchID = Request.Form["drpNCBench"].ToString();
                }
                else if (Request.Form["drpcourtname"].ToString() == "TN")
                {
                    addcase.BenchID = Request.Form["divTNBench"].ToString();
                }
                else if (Request.Form["drpcourtname"].ToString() == "RH")
                {
                    addcase.BenchID = Request.Form["divRHBench"].ToString();
                }
                else if (Request.Form["drpcourtname"].ToString() == "JK")
                {
                    addcase.BenchID = Request.Form["divJKBench"].ToString();
                }

                aff = AddCaseObjectController.InsertCaseDetail(addcase);
            }



            if (aff > 0)
            {
                TempData["SUCCESS"] = "Case Detail Added Successfully !!";
            }
            else
            {
                TempData["SUCCESS"] = "Case Detail Already Exist!!";
            }
            return RedirectToAction("AddCase", "AddCase");
        }

    }
}
