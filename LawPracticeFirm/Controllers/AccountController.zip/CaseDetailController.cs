﻿using System;
using System.Web.Mvc;


namespace NJDGDetail.Controllers
{
    public class CaseDetailController : Controller
    {
        //
        // GET: /CaseDetail/

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult GetCaseDetails()
        {
            return View();
        }

        public ActionResult ShowFullCaseDetails()
        {
            return View();
        }

        public ActionResult Data()
        {
            //CaseDetailObjectList casemasterddata = CaseDetailObjeController.ShowFullCaseData("608");
            //MyEventsDataContext data = new MyEventsDataContext();
            
            return View();
        }

        public ActionResult CalendarTest()
        {
            return View();
        }
        //[HttpPost]
        //[ValidateInput(false)]
        //public ActionResult SaveCertificate()
        //{
        //    string iid = Request.Form["hdnqrystr"];
        //    try
        //    {
               
        //        string username = Convert.ToString(Session[Global.LOGGED_USERID]);
        //        var file = Request.Files["fileCertificate"];

        //        if (file.ContentLength > 0)
        //        {
        //            HttpPostedFileBase pdffile = Request.Files["fileCertificate"];
        //            //string _directoryName = Directory.CreateDirectory(Server.MapPath("\\File\\" + username));
        //            string _directoryName = Server.MapPath("\\File\\" + username);
        //            if (!Directory.Exists(_directoryName))
        //            {
        //                Directory.CreateDirectory(Server.MapPath("\\File\\" + username));
        //                _directoryName = Server.MapPath("\\File\\" + username);
        //            }
        //            string[] fileExt = Request.Files["fileCertificate"].FileName.Split('.');
        //            string fileName = file.FileName;
        //            string PDFActualPath = _directoryName + fileName;


        //            int aff = AddCaseObjectController.InsertCaseUploadDocumentDetail(fileName, username, iid);
        //            if (aff > 0)
        //            {
        //                Request.Files["fileCertificate"].SaveAs(PDFActualPath);
        //                TempData["SUCCESS"] = "Documnet Uploaded Successfully !!";
        //            }
        //            else
        //            {
        //                TempData["SUCCESS"] = "Documnet Already Exist !!";
        //            }
        //        }
                

        //    }
        //    catch (Exception ex)
        //    {
        //        //Session[GLOBAL.ACTION_RESULT] = "Unable to update the PDF file, please check to admin with message: " + ex.Message;
        //    }
        //    return RedirectToAction("ShowFullCaseDetails?id=" + iid, "CaseDetail");
        //}

        [HttpPost]
        [ValidateInput(false)]
        public ActionResult SaveNotes()
        {

            string iid = Request.Form["hdnqrystr"];
            try
            {
                string notes = Request.Form["txtnote"];
                //string username =Convert.ToString(Session[Global.LOGGED_USERID]);
               
                //int aff = AddCaseObjectController.InsertCaseNotesDetail(notes, username,iid);
                //if (aff > 0)
                //{
                //    TempData["SUCCESS"] = "Notes Added Successfully !!";
                //}
                //else
                //{
                //    TempData["SUCCESS"] = "Notes Already Exist !!";
                //}


            }
            catch (Exception ex)
            {
                //Session[GLOBAL.ACTION_RESULT] = "Unable to update the PDF file, please check to admin with message: " + ex.Message;
            }
            return RedirectToAction("ShowFullCaseDetails?id=" + iid, "CaseDetail");
        }
    }
}
