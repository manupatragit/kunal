﻿ using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using NJDGDetail.Models;
using System.Data.SqlClient;
using NJDGDetail.DAL;
using NJDGDetail.BAL;

namespace NJDGDetail.Controllers
{
    public class CalendarEventController : Controller
    {
        //
        // GET: /CalendarEvent/
        static int idIndex = 0;
        static int startdateIndex = 0;
        static int enddateIndex = 0;
        static int textIndex = 0;
        static int useridIndex = 0;
        static int courseidIndex = 0;
        static int createdbyIndex = 0;
        static int isshowIndex = 0;
        static int createddateIndex = 0;
        static int isautocreatedIndex = 0;
        static int coursenameIndex = 0;
        static int showstatusIndex=0;

        static int usernameIndex = 0;
        static int orderdatefinalIndex = 0;
        static int cntIndex = 0;


        static int caseidIndex = 0;
        static int casetypeIndex = 0;
        static int casenoIndex = 0;
        static int caseyearIndex = 0;
        static int courtIndex = 0;
        static int localfileIndex = 0;
        static int disposeddtIndex = 0;
        static int casenameIndex = 0;
        static int advnameIndex = 0;        
        static bool isInitialized = false;

        #region Private static methods

        private static bool InitializeIndex(SqlDataReader reader)
        {
            if (reader.HasRows)
            {
                if (!isInitialized)
                {
                    idIndex = reader.GetOrdinal("iid");
                    startdateIndex = reader.GetOrdinal("vorderDateFinal");
                    enddateIndex = reader.GetOrdinal("vorderDateFinal");
                    textIndex = reader.GetOrdinal("vLocalFile");
                    //useridIndex = reader.GetOrdinal("UserId");
                    //courseidIndex = reader.GetOrdinal("CourseId");
                    //createdbyIndex = reader.GetOrdinal("CreatedBy");
                    //isshowIndex = reader.GetOrdinal("IsShow");
                    //createddateIndex = reader.GetOrdinal("CreatedDate");
                    //isautocreatedIndex = reader.GetOrdinal("IsAutocreated");
                    coursenameIndex = reader.GetOrdinal("vCaseName");
                    showstatusIndex = reader.GetOrdinal("vshowstatus");
                    isInitialized = true;
                }
                return true;
            }
            return false;
        }

        #endregion

        #region Public static methods

        private static CalendarEventClass ReadData(SqlDataReader reader)
        {
            CalendarEventClass ce = new CalendarEventClass();
            ce.id = reader.GetInt32(idIndex);

            if (reader.GetValue(startdateIndex) != DBNull.Value)
            {
                ce.start_date = reader.GetString(startdateIndex);
            }

            if (reader.GetValue(enddateIndex) != DBNull.Value)
            {
                ce.end_date = reader.GetString(enddateIndex);
            }

            if (reader.GetValue(textIndex) != DBNull.Value)
            {
                ce.text = reader.GetString(textIndex);
            }
            else
            {
                ce.text = "";
            }

            if (reader.GetValue(coursenameIndex) != DBNull.Value)
            {
                ce.CourseName = reader.GetString(coursenameIndex);
            }
            else
            {
                ce.CourseName = "";
            }
            if (reader.GetValue(showstatusIndex) != DBNull.Value)
            {
                ce.Showstatus = reader.GetString(showstatusIndex);
            }
            else
            {
                ce.Showstatus = "";
            }

            return ce;
        }

        public static EventList GetCalendarEventByUserId(string Id)
        {
            EventList eventList = new EventList();
            SqlParameter[] param = new SqlParameter[1];
            param[0] = new SqlParameter("@caseid", Id);
            using (SqlDataReader reader = SqlDbDAL.GetDataReaderSP(SpNames.ShowFullCaseData, param))
            {
                try
                {
                    isInitialized = false;
                    if (InitializeIndex(reader))
                    {
                        while (reader.Read())
                        {
                            eventList.Add(ReadData(reader));
                        }
                        isInitialized = false;
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return eventList;
        }



        private static bool InitializeByUsernameIndex(SqlDataReader reader)
        {
            if (reader.HasRows)
            {
                if (!isInitialized)
                {
                    idIndex = reader.GetOrdinal("iid");
                    startdateIndex = reader.GetOrdinal("vorderDateFinal");
                    enddateIndex = reader.GetOrdinal("vorderDateFinal");
                    isInitialized = true;
                }
                return true;
            }
            return false;
        }

        private static CalendarEventClass ReadDataByUsername(SqlDataReader reader)
        {
            CalendarEventClass ce = new CalendarEventClass();
            ce.id =Convert.ToInt32(reader.GetInt64(idIndex));

            if (reader.GetValue(startdateIndex) != DBNull.Value)
            {
                ce.start_date = reader.GetString(startdateIndex);
            }

            if (reader.GetValue(enddateIndex) != DBNull.Value)
            {
                ce.end_date = reader.GetString(enddateIndex);
            }

            return ce;
        }


        public static EventList GetCalendarEventByUserName(string username)
        {
            EventList eventList = new EventList();
            SqlParameter[] param = new SqlParameter[1];
            param[0] = new SqlParameter("@username", username);
            using (SqlDataReader reader = SqlDbDAL.GetDataReaderSP(SpNames.ShowFullCaseDataByUsername, param))
            {
                try
                {
                    isInitialized = false;
                    if (InitializeByUsernameIndex(reader))
                    {
                        while (reader.Read())
                        {
                            eventList.Add(ReadDataByUsername(reader));
                        }
                        isInitialized = false;
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return eventList;
        }


        private static bool InitializeByUsernameFullIndex(SqlDataReader reader)
        {
            if (reader.HasRows)
            {
                if (!isInitialized)
                {
                    idIndex = reader.GetOrdinal("iid");
                    startdateIndex = reader.GetOrdinal("vorderDateFinal");
                    enddateIndex = reader.GetOrdinal("vorderDateFinal");
                    isInitialized = true;
                }
                return true;
            }
            return false;
        }

        private static CalendarEventClass ReadDataByUsernameFull(SqlDataReader reader)
        {
            CalendarEventClass ce = new CalendarEventClass();
            ce.id = Convert.ToInt32(reader.GetInt64(idIndex));

            if (reader.GetValue(startdateIndex) != DBNull.Value)
            {
                ce.start_date = reader.GetString(startdateIndex);
            }

            if (reader.GetValue(enddateIndex) != DBNull.Value)
            {
                ce.end_date = reader.GetString(enddateIndex);
            }

            return ce;
        }



        private static bool InitializeByCaseUserDateFullIndex(SqlDataReader reader)
        {
            if (reader.HasRows)
            {
                if (!isInitialized)
                {
                    idIndex = reader.GetOrdinal("iid");
                    caseidIndex = reader.GetOrdinal("vCaseid");
                    casetypeIndex = reader.GetOrdinal("casetype");
                    caseyearIndex = reader.GetOrdinal("vCaseYear");
                    casenoIndex = reader.GetOrdinal("vcaseno");
                    disposeddtIndex = reader.GetOrdinal("vDisposedDate");
                    localfileIndex = reader.GetOrdinal("vlocalFile");
                    courtIndex = reader.GetOrdinal("vCourt");
                    orderdatefinalIndex = reader.GetOrdinal("vOrderdateFinal1");
                    casenameIndex = reader.GetOrdinal("vCaseName");
                    advnameIndex = reader.GetOrdinal("vAdvocateName");
                    showstatusIndex = reader.GetOrdinal("showstatus");
                    isInitialized = true;
                }
                return true;
            }
            return false;
        }

        private static CalendarEventClass ReadDataByCaseUserDateFullFull(SqlDataReader reader)
        {
            CalendarEventClass ce = new CalendarEventClass();
            ce.id = reader.GetInt32(idIndex);

            if (reader.GetValue(casetypeIndex) != DBNull.Value)
            {
                //ce.id = Convert.ToInt32(reader.GetString(caseidIndex));
            }

            if (reader.GetValue(casetypeIndex) != DBNull.Value)
            {
                ce.Casetype = reader.GetString(casetypeIndex);
            }

            if (reader.GetValue(casenoIndex) != DBNull.Value)
            {
                ce.CaseNo = reader.GetString(casenoIndex);
            }
            if (reader.GetValue(caseyearIndex) != DBNull.Value)
            {
                ce.Court = reader.GetString(courtIndex);
            }

            if (reader.GetValue(caseyearIndex) != DBNull.Value)
            {
                ce.Caseyear = reader.GetString(caseyearIndex);
            }

            if (reader.GetValue(disposeddtIndex) != DBNull.Value)
            {
                ce.Disposeddt = reader.GetString(disposeddtIndex);
            }
            if (reader.GetValue(localfileIndex) != DBNull.Value)
            {
                ce.Localfile = reader.GetString(localfileIndex);
            }
            if (reader.GetValue(orderdatefinalIndex) != DBNull.Value)
            {
                string startdate = reader.GetString(orderdatefinalIndex);
                //ce.LastFinaldate = Convert.ToDateTime(startdate, "yyyy-MM-dd hh:mm:ss",null);
                ce.start_date= reader.GetString(orderdatefinalIndex);
            }
           
            if (reader.GetValue(casenameIndex) != DBNull.Value)
            {
                ce.Casename = reader.GetString(casenameIndex);
            }
            if (reader.GetValue(advnameIndex) != DBNull.Value)
            {
                ce.Advname = reader.GetString(advnameIndex);
            }
            if (reader.GetValue(showstatusIndex) != DBNull.Value)
            {
                ce.Showstatus = reader.GetString(showstatusIndex);
            }
            return ce;
        }



        public static EventList GetCalendarEventByUserName1(string username,string date)
        {
            EventList eventList1 = new EventList();
            SqlParameter[] param = new SqlParameter[2];
            param[0] = new SqlParameter("@username", username);
            param[1] = new SqlParameter("@date", date);
            using (SqlDataReader reader = SqlDbDAL.GetDataReaderSP(SpNames.ShowMasterCaseBYUserName, param))
            {
                try
                {
                    isInitialized = false;
                    if (InitializeByCaseUserDateFullIndex(reader))
                    {
                        while (reader.Read())
                        {
                            eventList1.Add(ReadDataByCaseUserDateFullFull(reader));
                        }
                        isInitialized = false;
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return eventList1;
        }


        private static bool InitializeCountByUsernameIndex(SqlDataReader reader)
        {
            if (reader.HasRows)
            {
                if (!isInitialized)
                {
                    orderdatefinalIndex = reader.GetOrdinal("vorderDateFinal1");
                    cntIndex = reader.GetOrdinal("cnt");
                    useridIndex = reader.GetOrdinal("vusername");
                    isInitialized = true;
                }
                return true;
            }
            return false;
        }

        private static CalendarEventClass ReadDataCountByUsername(SqlDataReader reader)
        {
            CalendarEventClass ce = new CalendarEventClass();
            //ce.id = Convert.ToInt32(reader.GetInt64(idIndex));
            if (reader.GetValue(cntIndex) != DBNull.Value)
            {
                ce.Count = reader.GetInt32(cntIndex);
            }
            if (reader.GetValue(orderdatefinalIndex) != DBNull.Value)
            {
                ce.Disposeddt = reader.GetString(orderdatefinalIndex);
            }
            if (reader.GetValue(useridIndex) != DBNull.Value)
            {
                ce.username_ = reader.GetString(useridIndex);
            }



            return ce;
        }


        

             public static EventList CountCaseBYUserName(string username)
        {
            EventList eventList = new EventList();
            SqlParameter[] param = new SqlParameter[1];
            param[0] = new SqlParameter("@id", username);
            using (SqlDataReader reader = SqlDbDAL.GetDataReaderSP(SpNames.CountCaseBYUserName, param))
            {
                try
                {
                    isInitialized = false;
                    if (InitializeCountByUsernameIndex(reader))
                    {
                        while (reader.Read())
                        {
                            eventList.Add(ReadDataCountByUsername(reader));
                        }
                        isInitialized = false;
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return eventList;
        }
        public static EventList CountCaseBYFirmUserId(string username)
        {
            EventList eventList = new EventList();
            SqlParameter[] param = new SqlParameter[1];
            param[0] = new SqlParameter("@id", username);
            using (SqlDataReader reader = SqlDbDAL.GetDataReaderSP(SpNames.CountCaseBYFirmUserId, param))
            {
                try
                {
                    isInitialized = false;
                    if (InitializeCountByUsernameIndex(reader))
                    {
                        while (reader.Read())
                        {
                            eventList.Add(ReadDataCountByUsername(reader));
                        }
                        isInitialized = false;
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return eventList;
        }


        //public static int AddEvents(CalendarEventClass calendar)
        //{
        //    try
        //    {

        //        SqlParameter[] param = new SqlParameter[9];
        //        param[0] = new SqlParameter("@startdate", calendar.start_date);
        //        param[1] = new SqlParameter("@enddate", calendar.end_date);
        //        param[2] = new SqlParameter("@text", calendar.text);
        //        param[3] = new SqlParameter("@UserId", calendar.UserId);
        //        param[4] = new SqlParameter("@CourseId", calendar.CourseId);
        //        param[5] = new SqlParameter("@CreatedBy", calendar.CraetedBy);
        //        param[6] = new SqlParameter("@IsShow", calendar.IsShow);
        //        param[7] = new SqlParameter("@id", calendar.id);
        //        param[8] = new SqlParameter("@isAuto", calendar.IsAutocreated);

        //        //param[7].Direction = ParameterDirection.Output;
        //        SqlDbDAL.ExecuteNonQuerySP(SpNames.AddCalendarEvent, param);
        //        //calendar.id = Convert.ToInt32(param[7].Value);

        //        return calendar.id;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }

        //}

        //public static EventList GetCalendarEvents(int Id)
        //{
        //    EventList eventList = new EventList();
        //    SqlParameter[] param = new SqlParameter[1];
        //    param[0] = new SqlParameter("@Id", Id);
        //    using (SqlDataReader reader = SqlDbDAL.GetDataReaderSP(SpNames.ViewEvents, param))
        //    {
        //        try
        //        {
        //            isInitialized = false;
        //            if (InitializeIndex(reader))
        //            {
        //                while (reader.Read())
        //                {
        //                    eventList.Add(ReadData(reader));
        //                }
        //                isInitialized = false;
        //            }
        //        }
        //        catch (Exception ex)
        //        {
        //            throw ex;
        //        }
        //    }
        //    return eventList;
        //}

        #endregion




    }
}
